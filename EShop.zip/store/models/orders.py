from django.db import models
from .product import Product
from .customer import Customer
import datetime

class Order(models.Model):
	product = models.ForeignKey(Product , on_delete=models.CASCADE)
	customer = models.ForeignKey(Customer , on_delete=models.CASCADE)
	quantity = models.IntegerField(default=1)
	price = models.IntegerField()
	firstName = models.CharField(max_length=50 , default='' , blank=True)
	lastName = models.CharField(max_length=50 , default='' , blank=True)
	companyName = models.CharField(max_length=50 , default='' , blank=True)
	address1 = models.CharField(max_length=50 , default='' , blank=True)
	address2 = models.CharField(max_length=50 , default='' , blank=True)
	postcode = models.CharField(max_length=50 , default='' , blank=True)
	city = models.CharField(max_length=50 , default='' , blank=True)
	phone = models.IntegerField()
	email = models.CharField(max_length=50 , default='' , blank=True)
	additional = models.CharField(max_length=50 , default='' , blank=True)
	status = models.BooleanField(default=False)
	date = models.DateField(default=datetime.datetime.today)


	def placeOrder(self):
		self.save()


	@staticmethod
	def get_orders_by_customer(customer_id):
		return Order.objects.filter(customer = customer_id).order_by('date')