from django.shortcuts import render, redirect
# Create your views here.
from store.models.product import Product
from store.models.category import Category
from django.views import View

def contact(request):
	return render(request, 'contact.html')

# def checkout(request):
# 	firstName = request.POST.get('firstName')
# 	lastName = request.POST.get('lastName')
# 	companyName = request.POST.get('companyName')
# 	address1 = request.POST.get('address1')
# 	address2 = request.POST.get('address2')
# 	postcode = request.POST.get('postcode')
# 	city = request.session.get('city')
# 	phone = request.session.get('phone')
# 	email = request.session.get('email')
# 	additional = request.session.get('additional')

# 	customer = request.session.get('customer')
# 	cart = request.session.get('cart')
# 	products = Product.get_products_by_id(list(cart.keys()))

# 	for product in products:
# 		order = Order(customer = Customer(id=customer) , product = product , price = product.price , firstName = firstName , lastName = lastName , companyName = companyName ,  address1 = address1 , address2 = address2 , postcode = postcode , city = city , phone = phone , email = email , additional = additional , quantity = cart.get(str(product.id)))
# 		order.save()
# 	request.session['cart'] = {}
# 	return redirect('checkout')
# 	# return render(request, 'checkout.html')
