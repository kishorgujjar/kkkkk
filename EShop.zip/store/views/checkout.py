from django.shortcuts import render, redirect
# Create your views here.
from store.models.product import Product
from store.models.customer import Customer
from store.models.orders import Order
from django.views import View


class CheckOut(View):
	def post(self , request):
		firstName = request.POST.get('firstName')
		lastName = request.POST.get('lastName')
		companyName = request.POST.get('companyName')
		address1 = request.POST.get('address1')
		address2 = request.POST.get('address2')
		postcode = request.POST.get('postcode')
		city = request.POST.get('city')
		phone = request.POST.get('phone')
		email = request.POST.get('email')
		additional = request.POST.get('additional')
		customer = request.session.get('customer')
		cart = request.session.get('cart')
		products = Product.get_products_by_id(list(cart.keys()))

		for product in products:
			order = Order(customer = Customer(id=customer) , product = product , price = product.price , firstName = firstName , lastName = lastName , companyName = companyName ,  address1 = address1 , address2 = address2 , postcode = postcode , city = city , phone = phone , email = email , additional = additional , quantity = cart.get(str(product.id)))
			order.save()
		request.session['cart'] = {}
		return redirect('checkout')
	

